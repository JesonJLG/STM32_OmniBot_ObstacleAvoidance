#ifndef __GPIO_H
#define __GPIO_H

#include "stm32f4xx.h"


#define LED PCout(13)

void GIPO_init(void);


#endif
