#ifndef __GAP_H
#define __GAP_H	
#include "sys.h" 
#include "usart.h"
#include "delay.h"


void TIM2_Gap_Init(u32 arr,u32 psc);	
void TIM2_Gap_text(void);
	
	
#endif


