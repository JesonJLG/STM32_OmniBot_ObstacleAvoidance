#ifndef __TIMER_H
#define __TIMER_H	
#include "sys.h" 


void TIM2_Init(u32 arr,u32 psc);
void TIM3_Init(u32 arr,u32 psc);
void TIM4_Init(u32 arr,u32 psc);

	
#endif


