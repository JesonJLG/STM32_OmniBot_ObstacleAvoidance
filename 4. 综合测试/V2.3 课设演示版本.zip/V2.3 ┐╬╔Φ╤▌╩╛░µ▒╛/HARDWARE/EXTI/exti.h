#ifndef __EXTI_H
#define __EXTI_H 			   
#include "sys.h"  
 

void EXTI4_init(void);


#endif
