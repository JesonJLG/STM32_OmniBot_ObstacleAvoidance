#ifndef   _KEY_H_
#define   _KEY_H_
#include "sys.h"


void Key_Init(void);
uint16_t Key_scan(void);

#endif
