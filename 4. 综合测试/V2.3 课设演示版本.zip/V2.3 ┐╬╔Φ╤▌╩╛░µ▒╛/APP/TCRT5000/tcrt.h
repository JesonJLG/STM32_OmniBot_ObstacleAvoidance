#ifndef __TCRT_H
#define __TCRT_H	 
#include "sys.h"
#include "delay.h"
#include "led.h"
#include "adc.h"
#include "usart.h"




void TCRT5000_Init(void);
void Tcrt_Text(void);


#endif



